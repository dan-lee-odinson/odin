# Deposit MC-M9-02

- Milestone: M9 follow-up. This is MC-M9-01's contents plus one fix, deposited
  as MC-M9-02 because MC-M9-01 is already out.
- Status: deposited as MC-M9-02.zip on the Director's word, 2026-10-28.
- Layout: this file sits at the top of the deposit zip, beside `odin/`, identical to
  the copy beside the zip. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-28 (full suite and red case shown in session).

## The fix

The start command's stand-in answered `{"kind":"none"}` on every turn,
report turns included, so a stand-in run through the command logged
MALFORMED answers on REPORT turns. Now `stand_in_answer` in
`odin/run_odin.py` answers none on an ACT turn and, on a REPORT turn, a
minimal valid report of the form that turn asks for: the five report-body
fields, plus `answer` on a CHECK_IN report and no `answer` on the others.

## Tests run

`python -m pytest odin/tests/` in the project .venv on 2026-10-28:
182 passed, 1 skipped (the real-key match test this sandbox cannot read; it
runs on the Director's machine with `ODIN_KEY_MATCH_REQUIRED=1`).

New test: `test_stand_in_answers_report_turns_with_a_report` in
`odin/tests/test_m8_start.py` runs the command on stand_in through ACT,
PASS_START and CHECK_IN turns and checks two reports are filed, the
CHECK_IN report carries an answer, the other does not, and no MALFORMED
record is logged. It failed before the fix.

Red case: `stand_in_answer` planted to return `{"kind":"none"}` on a
REPORT turn — the test ran and failed. Restored byte for byte (SHA-256
9b5b453e…9ea7 verified against the pre-plant value).

The three frozen files are unchanged: `odin/instructions/system_prompt.md`
still hashes to sha256:3a91b23fd4a533c04a8821fa01743c7d6e0062b6956a02eae703864220cf9f8c,
and the freeze guard passes.

No paid call was made.

## Suggested commit message

M9 follow-up: start command's stand-in answers report turns with a report

Built-with: Muse Code (muse-wonder-1.0)
