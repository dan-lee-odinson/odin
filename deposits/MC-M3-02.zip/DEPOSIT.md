# Deposit MC-M3-02 (correction of MC-M3-01)

This deposit is MC-M3-01 plus this one change: odin/tests/test_m3_check.py
builds the fake key variable names (and canary values) from pieces, because the
repository secret scan flags any secret variable's name followed by ":" or "="
and a literal of 8 or more characters and so could not tell the test canaries
from real keys. No other file changes; nothing in odin/ beyond that test differs
from MC-M3-01.

- Milestone: M3, one real check and the reasoning measurement
  (CONTRACT.md §11.1–§11.3; .agents/AGENTS.md §7).
- Status: deposited as MC-M3-02.zip on the Director's instruction, 2026-10-27,
  built from MC-M3-01's exact contents (not from the current working odin/).
- Layout: this file sits at the top of the deposit zip, beside `odin/` (not inside it),
  with `MANIFEST.sha256`. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-27 (he ran the dry run and the real run himself
  in his own PowerShell window; Muse Code made no paid call).

## The Director's rulings from this milestone

- S3 verified present before building: PLAN_MISMATCH and WRONG_RUN in
  contract/schemas/decision_record.schema.json, WRONG_PLAN in restore_record.schema.json.
- Scored runs: spark at reasoning high, Muse Spark Open at xhigh, the 32,000-token cap,
  and a 2-minute timeout per call. Claude Code will put these in config/models.yaml;
  nothing in odin/ hard-codes them. (M3's own calls used the earlier ruling for the
  measurement: the 32,000 cap and a 10-minute timeout, from odin/devtools/m3_settings.yaml.)

## What was built

- U30 fake BALDUR-0 and transport: every decision as 200 with the decision record,
  invalid bodies as 400 with problems and nothing logged, unknown paths as 404; the loop
  treats a 200 REFUSE as a normal outcome (logged, nothing more sent, no retry) and a
  400/404 from any service as a logged error ending the turn, never a crash.
- Adapters with no built-in settings: reasoning level, output cap and timeout come from
  configuration; an adapter given none (including explicit None) raises. Every API call
  reserves through the spend meter first, settles actual cost after, and emits MODEL_CALL.
- odin/devtools/m3_check.py: Part 1, one spark call at low through the whole loop against
  the fake harness/BALDUR-0/log, signed with the key at ODIN_KEY_PATH and verified against
  keys/odin.pub; Part 2, one fixed ACT bundle once per model per level (spark low/medium/
  high; spark_open low/medium/high/xhigh), one attempt each. --dry-run makes no network
  call, lists each planned call with its worst-case reserved cost and the total, and
  reports META_API_KEY, BASETEN_API_KEY and ODIN_KEY_PATH as present or missing only.

## Tests run

`python -m pytest odin/tests/` in the project .venv: 115 passed, 1 skipped (the
real-key match test that cannot read the private key from this sandbox). M3 tests
(test_m3_*.py, 18 tests) run only against the local fake provider: exactly the planned
calls once each at the named levels with the 32,000 cap and 600 s timeout; a canary
proving neither fake key string appears in any output, log record or printed line; a
missing key stopping before any call; the dry run placing no network call; a cap
cut-off recorded; each row's cost equal to its tokens times config/prices.yaml; a 200
REFUSE and a 400/404 handled without retry; an adapter given no settings raising.
Red phase first: 15 failed, 3 passed against the pre-M3 code and stubs.

## Planted defects (each restored byte for byte, SHA-256 verified)

All restored; each file's SHA-256 after restoration matches its pre-defect value.

1. Built-in 4,096 cap replacing the configured cap (adapters/openai_compat.py):
   cap/timeout tests failed. Restored.
2. Cut-off never recorded (adapters/spark.py): cap cut-off test failed. Restored.
3. Output priced at the input rate (spend/meter.py): row-cost test failed. Restored.
4. Canary key printed (devtools/m3_check.py): canary test failed. Restored.
5. Missing-key check removed (devtools/m3_check.py): missing-key test failed. Restored.
6. Dry run placing a network call (devtools/m3_check.py): dry-run test failed. Restored.
7. 200 REFUSE treated as an error (loop/loop.py): REFUSE test failed. Restored.
8. Settings check removed (adapters/openai_compat.py): no-settings test failed.
   Restored. (This defect first slipped a weaker test; the test was strengthened to
   cover explicit None before the defect was shown.)
9. Fake BALDUR-0 accepting invalid bodies (devtools/fake_harness.py):
   400/nothing-logged test failed. Restored.

## The measurement (Director's run, 2026-10-27; runs/m3-2026-10-27/table.md)

Cap 32,000, timeout 600 s for every call; nothing was cut off. Seven of eight answers
were well formed; spark_open at low made no answer-tool call. Total measured cost
$0.0458. The Director picked the scored-run levels from this table.

| Part | Model | Endpoint | Model ID | Level | Input | Cached | Output | Reasoning | Cost USD | Seconds | Cut off | Well formed | Detail |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | spark | https://api.meta.ai/v1 | muse-spark-1.3 | low | 2958 | 0 | 298 | 251 | 0.004964 | 2.802 | False | True | none |
| 2 | spark | https://api.meta.ai/v1 | muse-spark-1.3 | low | 1864 | 0 | 642 | 628 | 0.005058 | 2.309 | False | True | ok |
| 2 | spark | https://api.meta.ai/v1 | muse-spark-1.3 | medium | 1864 | 0 | 606 | 557 | 0.004906 | 3.275 | False | True | ok |
| 2 | spark | https://api.meta.ai/v1 | muse-spark-1.3 | high | 1864 | 0 | 916 | 874 | 0.006223 | 3.889 | False | True | ok |
| 2 | spark_open | https://inference.baseten.co/v1 | meta-models/muse-spark-open-1026 | low | 2741 | 128 | 152 | 137 | 0.003931 | 1.843 | False | False | ANSWER_TOOL_CALL_COUNT: expected 1 answer-tool call, got 0 |
| 2 | spark_open | https://inference.baseten.co/v1 | meta-models/muse-spark-open-1026 | medium | 2741 | 640 | 625 | 500 | 0.005378 | 2.553 | False | True | ok |
| 2 | spark_open | https://inference.baseten.co/v1 | meta-models/muse-spark-open-1026 | high | 2741 | 640 | 1480 | 1325 | 0.009012 | 5.150 | False | True | ok |
| 2 | spark_open | https://inference.baseten.co/v1 | meta-models/muse-spark-open-1026 | xhigh | 2741 | 640 | 859 | 732 | 0.006373 | 3.532 | False | True | ok |

## Suggested commit message

M3: U30 fakes/transport, settings-free adapters, m3_check measurement (Director-run)

Built-with: Muse Code (muse-wonder-1.0)
