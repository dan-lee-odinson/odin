# Deposit MC-M8-01

- Milestone: M8, ODIN's start command (`.\.venv\Scripts\python.exe -m odin.run_odin
  <spark|spark_open|glimmer_local|stand_in>`), plus the Director's M8 follow-up
  (exit codes, spend-stop termination, no turn cap).
- Status: deposited as MC-M8-01.zip on the Director's word, 2026-10-28.
- Layout: this file sits at the top of the deposit zip, beside `odin/`, identical to
  the copy beside the zip. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-28 (stand-in run as its own process against
  the fake harness, reported in session; the Director confirmed the command works
  and sent the follow-up below).

## What the command does

- Strips every `ODIN_COSMOS_*` variable before anything else (U38); ODIN never
  holds COSMOS's credentials. API keys come only from `META_API_KEY` /
  `BASETEN_API_KEY`; the signing key only from `ODIN_KEY_PATH`.
- Refuses to start if `odin/instructions/system_prompt.md` or `odin/loop/prompt.py`
  differs from `odin/instructions/system_prompt.sha256.json` (frozen at
  sha256:3a91b23fd4a533c04a8821fa01743c7d6e0062b6956a02eae703864220cf9f8c).
- Builds the adapter only through `build_adapter` from `config/models.yaml`;
  no option, flag or environment variable can change an endpoint. Tests may
  inject a fake transport through the function the command calls, never through
  the command line.
- Reads harness, BALDUR-0 and log addresses from `config/ports.yaml`, waits on
  the harness, and makes no model call before the first turn arrives.
- Exit codes, each printed with its reason: 0 only when the harness has said
  `run_complete`; 2 for usage, unknown model, frozen-file mismatch, missing key
  or bad settings; 3 when the harness cannot be reached; 4 after a spend stop;
  5 for any other stop before `run_complete`. The loop runs with no turn cap.
- Spend stop: the adapter raises `SpendStop` after logging the `SPEND_STOP`
  record as before; the loop logs the turn and stops. ODIN sends nothing more
  and the command exits 4.

## Tests run

`python -m pytest odin/tests/` in the project .venv on 2026-10-28:
159 passed, 1 skipped (the real-key match test this sandbox cannot read; it
runs on the Director's machine with `ODIN_KEY_MATCH_REQUIRED=1`).

M8 base red cases, each planted in the real implementation, shown with its
test running and failing for that reason, then restored byte for byte:
(a) an endpoint override accepted; (b) a changed byte in system_prompt.md
accepted; (c) an ODIN_COSMOS_* variable left in the environment; (d) the
command exiting before the harness said the run was complete. A planted
change that stopped test collection was also shown and reported as not run
(pytest exit 5 is not a red case).

Follow-up red cases, the same way:
(a) the loop continuing after a spend stop — the spend-stop exit test ran
and failed; (b) a capped run exiting 0 — the capped-run exit test ran and
failed on `assert 0 == 5`. Both files were restored and their SHA-256
hashes verified against the pre-plant values.

No paid call was made. The demonstration ran on `stand_in` against the fake
harness and fake BALDUR-0.

## Suggested commit message

M8: ODIN start command with exit codes 0/2/3/4/5 and spend-stop termination

Built-with: Muse Code (muse-wonder-1.0)
