# Deposit MC-M13-01

- Milestone: M13, one re-pinned hash. Phase 1's third scored run showed
  the report format refused a "NaN" that COSMOS really showed for INST's
  TEMP2. By the Director's ruling, common.schema.json now takes INST's
  numeric values from observation.schema.json; Claude Code refreshed the
  workspace with the new schema and config/frozen.json.
- Status: deposited as MC-M13-01.zip on the Director's word, 2026-10-29.
- Layout: DEPOSIT.md sits at the top of the deposit zip beside `odin/`. The
  copy beside the zip is named MC-M13-01.DEPOSIT.md so a later deposit
  cannot overwrite it, and is identical to the one inside.
  keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-29 (full suite and red case shown in session).

## The change

One line in odin/: in `FROZEN_SIX` in
`odin/tests/test_m10_tools_schema.py`, the "common.schema.json" entry
now reads sha256:929284182c6dc7af7fdfb29319d1d21b40dc0e6a83c774553855c46bb492e10d,
checked against the refreshed file in the workspace (and against
config/frozen.json) before it was written. Nothing else in odin/
changed; a diff of the whole odin/ tree against MC-M12-01 shows only
that file. This deposit's builder was run from outside odin/ so the
tree stays that way.

## Tests run

`python -m pytest odin/tests/` in the project .venv on 2026-10-29:
234 passed, 1 skipped (the real-key match test this sandbox cannot read).

Red case: with the old hash
(sha256:5d2cbe916cee8c68a73d89fe4dab29654cfe9085561b620f3e13d378716eb9dc)
put back, test_six_schemas_and_models_yaml_unchanged failed; shown
failing, then the new hash restored and the suite run again green.
The same failure was shown before the change was first written.

## Unchanged

The three frozen files still hash as recorded, the freeze guard passes,
the other five schemas and config/models.yaml are unchanged, and no
contract schema file was touched by Muse Code. No paid call was made.

## Suggested commit message

M13: re-pin FROZEN_SIX common.schema.json to the refreshed schema hash

Built-with: Muse Code (muse-wonder-1.0)
