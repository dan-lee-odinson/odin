# Deposit MC-M4-01

- Milestone: M4, the study step, plus the Director's follow-ups U39, U43 and the
  model-settings ruling (CONTRACT.md §11, §10.4; .agents/AGENTS.md §4.4, §7).
- Status: deposited as MC-M4-01.zip on the Director's go-ahead, 2026-10-27.
- Layout: this file sits at the top of the deposit zip, beside `odin/`, identical to
  the copy beside the zip. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-27 (follow-ups and study build shown in session;
  the Director ran the paid study call himself at 22:52 and accepted the reference).

## The frozen reference (Director-run, accepted as frozen)

- odin/study/cosmos_reference.md, SHA-256
  sha256:c3f964cd81bd07a834c37c0e2c8ac503dbac2394e5e70c517dc8c4c8812e234f,
  verified against odin/study/cosmos_reference.json after the run.
- Written by one spark call (reasoning high, cap 64,000, timeout 1,800 s) from the
  98 fetched docs (OpenC3 COSMOS v7.2.1, cache/cosmos-docs-7.2.1/, hashes in
  odin/study/cosmos_docs_hashes.json; the repository holds no docs). Plain text:
  no answer schema, no tools. Metered like every call; the spend ledger sits
  beside the record (cosmos_reference.spend.jsonl).
- Record facts: finish_reason stop; 328,958 input tokens; 6,334 output tokens
  (1,991 reasoning); actual cost $0.438117. Nothing was cut off.
- License: the frozen reference opens with the code-written header (Muse Spark,
  modified from the OpenC3 COSMOS v7.2.1 documentation; Copyright © 2026
  OpenC3, Inc.; used under the OpenC3 Builder's License, its name read from the
  fetched LICENSE.md's title). odin/study/LICENSE.md is kept beside the reference
  and its hash matches the recorded list. The license's three asks are met:
  its terms travel with the reference, the modification is stated prominently
  in the header, and no OpenC3 notice is removed.

## Follow-ups built first (each with a test and a live planted red case)

- U39: GET /turn/next may wait 120 s; a timeout asks again, never crashes.
  Planted raise-on-timeout failed its test; restored byte for byte.
- Settings: scored runs read config/models.yaml (spark high, spark_open xhigh,
  32,000 tokens, 120 s, the Director's 27 October rulings); nothing in odin/
  hard-codes them; a missing or incomplete file stops a run before any call.
  Planted hard-coded values failed the read-not-hardcoded test; restored.
- U43: the harness attaches plan references by hash in the bundle; the loop
  builds the prompt from the bundle alone (instructions, plan, procedures and
  attachments, changing parts last) and checks each attachment's SHA-256
  against the plan's references — a mismatch ends the turn logged, no model
  call. Planted never-check failed its test; restored.

## Fixes before the paid call (each with a test and a live red case)

1. Study call plain text through the real SparkAdapter: planting the answer
   schema back failed the request-body test. Restored.
2. A cut-off or empty answer freezes nothing: disabling both guards failed
   both tests (no reference, license copy or record is written). Restored.
3. Docs verified (fetch --verify plus no-extra-files) before any call: one
   changed byte stopped the run with zero provider calls when checking was
   planted away. Restored.
4. The call is metered, and its record carries model, provider, the three
   settings, token counts, actual cost, finish reason, latency, system-clock
   UTC, and the SHA-256 of the instructions and of cosmos_docs_hashes.json.
5. Instructions name their reader (an AI operator through COSMOS), scope
   COSMOS only (definitions, units, states, limits, limit states, alarms),
   cap the body at about 10,000 words, and repeat after the docs; a test
   proves the prompt holds no "HUGINN". Removing the tail repeat failed it.

## Tests run

`python -m pytest odin/tests/` in the project .venv: 137 passed, 1 skipped (the
real-key match test this sandbox cannot read). The M4 goal's red-first phases:
follow-up tests 5 failed against stubs/current code; study tests 7 failed
against stubs; each was then made to pass. The fetch ran pinned to v7.2.1
(99 files including LICENSE.md, 1,498,131 bytes) with every hash re-verified.

## Suggested commit message

M4: U39/U43 follow-ups, models.yaml settings, COSMOS fetch and frozen study reference

Built-with: Muse Code (muse-wonder-1.0)
