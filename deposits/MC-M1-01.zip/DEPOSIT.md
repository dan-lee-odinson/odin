# Deposit MC-M1-01

- Milestone: M1, the loop on the stand-in (CONTRACT.md §4, §6–§8; .agents/AGENTS.md §4.1, §7).
- Status: deposited as MC-M1-01.zip on the Director's go-ahead, 2026-10-26.
- Layout: this file sits at the top of the deposit zip, beside `odin/` (not inside it),
  with `MANIFEST.sha256` and `keys/odin.pub` if it changed (to be added at deposit time).
- Date the Director saw it run: 2026-10-26 (full test run shown in session; go-ahead given).
- S2 additions included: canonical-JSON vectors (U22), seven log record types (U21),
  log/report reply shapes (U24).

## Tests run

Command (workspace root, project `.venv`):
`python -m pytest odin/tests/test_m1_*.py` (expanded to the five test files under PowerShell,
which does not expand the glob itself).

Result: 87 passed, 1 skipped. The skip is
`test_repo_pub_matches_env_key_when_set`: ODIN's private key is unreadable from this sandbox
by design (CONTRACT.md §2 rule 5). It skips with that reason, and fails instead when
`ODIN_KEY_MATCH_REQUIRED=1` — both modes demonstrated.

Coverage: 20-turn stand-in run end to end; every malformed form rejected
(NOT_ONE_JSON_OBJECT, SCHEMA_VIOLATION, WRONG_FORM_FOR_TURN, ANSWER_TOOL_CALL_COUNT);
saved input bytes hash to the logged hashes; signature verifies with the public key and
fails after a one-byte change; the model never sets request_id, origin, nonce or signature;
spark_open answer-tool conversion on recorded responses with no network call; RFC 8032
§7.1 TEST 1 for the signer; no file imports `ve`; the secret scan finds nothing.
Signatures use the `cryptography` package (`Ed25519PrivateKey`, `load_ssh_private_key`);
keys/odin.pub is the public half of the Director's real key at ODIN_KEY_PATH
(fingerprint SHA256:Iv+MbzBJ/qxfLXKbixgv+nuTJoDRnhISNgUFH+OLCgc), verified from its
readable `.pub` file. Test keys are throwaway keys in temp folders only.

## Planted defects (each restored byte for byte, SHA-256 verified)

1. Validator accepts extra fields — `odin/loop/validate.py`: `additionalProperties: false`
   check disabled. Result: 12 failed, 29 passed in test_m1_validate.py (extra-field and
   forged-loop-field cases accepted). Restored; hash matches the pre-defect value.
2. Signer leaves `nonce` out of the signed bytes — `odin/loop/signing.py`:
   signature computed over the request without `nonce`. Result:
   test_signature_verifies_with_public_key and test_signature_fails_after_one_byte_change
   failed. Restored; hash matches.
3. Loop skips saving the bundle — `odin/loop/loop.py`: bundle-bytes write replaced by a
   no-op. Result: test_saved_inputs_hash_to_logged_hashes failed (saved file missing).
   Restored; hash matches.
4. spark_open accepts two answer-tool calls — `odin/adapters/spark_open.py`: count check
   weakened to reject only zero calls. Result: test_two_answer_calls_is_malformed failed.
   Restored; hash matches.
5. Canonical JSON separator altered — `odin/loop/canonical.py`: `separators=(",", ": ")`
   in place of `(",", ":")` (S2, ruling U22). Result: 5 of 15 shared vectors in
   contract/schemas/canonical_vectors.json failed (every vector containing an object),
   including "a command request without its signature: the bytes ODIN signs".
   Restored; hash matches. The vector test also carries a red case proving an altered
   vector (one flipped byte) is caught, and that NaN/infinity are refused.

## Suggested commit message

M1: ODIN turn loop, answer check, input saving, request signing, fake harness/BALDUR-0

Built-with: Muse Code (muse-wonder-1.0)
