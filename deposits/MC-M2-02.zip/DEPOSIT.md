# Deposit MC-M2-02 (correction of MC-M2-01)

- Milestone: M2, the spend meter (CONTRACT.md §11.2–§11.3; .agents/AGENTS.md §4.3, §7).
- Status: deposited as MC-M2-02.zip on 2026-10-27. Identical to MC-M2-01.zip except
  for this file.
- Correction: MC-M2-01's DEPOSIT.md dated the deposit and the Director's review
  2026-10-26; both happened 2026-10-27. This deposit corrects those dates.
  `odin/` is unchanged.
- Layout: this file sits at the top of the deposit zip, beside `odin/` (not inside it),
  with `MANIFEST.sha256`. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-27 (full test run shown in session; go-ahead given).
- Boundary confirmed by the Director: a call landing exactly on a stop is allowed;
  §11.3 refuses only a call that would pass it.

## Tests run

Command (workspace root, project `.venv`):
`python -m pytest odin/tests/test_m2_*.py` (expanded to the test file under PowerShell,
which does not expand the glob itself). Result: 10 passed.

Red phase: the tests were first run against a stub meter that always allowed calls and
reported zero totals — all 10 failed on assertions (not collection errors). The real
meter then passed all 10. The M1 suite still passes unchanged (87 passed, 1 skipped).

Coverage: refusal when spent plus reserved would pass $125 (Meta), $90 (Baseten) and
$12.00 (Modal), including the boundary that landing exactly on a stop is allowed and one
cent past it is refused; worst-case reservation (full-price input plus max-output) replaced
by actual cost on settle, freeing the reservation; cached input priced at the cached rate;
the four amounts (Meta credit, Baseten credit, Modal credit, out-of-pocket) kept apart;
the append-only ledger surviving a restart with earlier lines untouched. Prices come from
config/prices.yaml at run time; no second copy is kept.

U21 additions: the meter submits SPEND (four running totals) after each settled call and
SPEND_STOP for each refused call through POST /log/agent, shaped as
contract/schemas/spend.schema.json and spend_stop.schema.json define. A test drives two
priced calls and checks the submitted SPEND totals equal both the meter totals and the sum
of the corresponding MODEL_CALL records' actual costs; another checks SPEND_STOP is
submitted once, with stop META, the $125 limit, and the refusing turn.

## Planted defects (each restored byte for byte, SHA-256 verified)

All in `odin/spend/meter.py`; the file's SHA-256 after every restoration matches its
pre-defect value.

1. Meta stop raised $125 → $12,500. Result: test_meta_stop_refuses_at_125 failed
   (call wrongly allowed). Restored; hash matches.
2. Baseten stop raised $90 → $900. Result: test_baseten_stop_refuses_at_90 failed.
   Restored; hash matches.
3. Modal stop raised $12.00 → $120. Result: test_modal_stop_refuses_at_12 failed.
   Restored; hash matches.
4. Settle credits the reservation instead of the actual cost. Result:
   test_actual_cost_replaces_reservation failed. Restored; hash matches.
5. Settle collapses every bucket into META_CREDIT. Result:
   test_four_amounts_kept_apart failed. Restored; hash matches.
6. Ledger truncated on construction (restart wipes it). Result:
   test_ledger_survives_restart_and_is_appended failed. Restored; hash matches.
7. SPEND record swaps the Baseten and Modal totals (the red case for the
   SPEND-equals-MODEL_CALL check). Result:
   test_spend_records_match_model_call_actuals failed. Restored; hash matches.

## Suggested commit message

M2: spend meter with worst-case reservation, stops, append-only ledger, SPEND/SPEND_STOP

Built-with: Muse Code (muse-wonder-1.0)
