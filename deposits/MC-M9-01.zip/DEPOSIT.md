# Deposit MC-M9-01

- Milestone: M9, the dictionary in force (U58). ODIN's answer check no longer
  reads a fixed dictionary file; on each turn it takes the dictionary the
  plan in force lists, through `config/dictionaries.yaml`.
- Status: deposited as MC-M9-01.zip on the Director's word, 2026-10-28.
- Layout: this file sits at the top of the deposit zip, beside `odin/`, identical to
  the copy beside the zip. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-28 (full suite and red cases shown in session).

## What changed

- `odin/loop/validate.py` loads the registry at `config/dictionaries.yaml`.
  On each turn the loop takes the plan in force from the bundle and finds
  the plan's references whose `sha256` matches a registry entry's reference:
  exactly one match uses that entry; none uses the registry's HUGINN entry;
  two or more is an error — the loop sends nothing, makes no model call, and
  logs the turn as an error, not as a malformed answer.
- The entry's file is read and its SHA-256 checked against the entry's
  `sha256`. A mismatch is the same kind of error: nothing is sent.
- The dictionary check runs before the generic schema check: the command is
  listed; its parameters are exactly the listed argument names; each value
  fits (enum in `enum_values`; a number within min and max for float; an
  integer within min and max for uint, never a bool). A command proposed in
  an escalation is checked the same way. Anything outside the dictionary is
  MALFORMED with reason `NOT_IN_DICTIONARY`, the detail naming the command
  or argument, and nothing is sent. It is never filed as `SCHEMA_VIOLATION`.
  `spark_open`'s answer-tool conversion goes through the same check.
- The fixed path to `deps/huginn/defs/tlm_cmd.yaml` is removed from the
  checker and adapters. HUGINN's dictionary is reached through the registry
  like any other. (One M7 test still reads that file directly, to prove no
  dictionary name appears in ODIN's instructions; that is test code, not
  the checker.)
- Earlier tests that filed out-of-dictionary commands as SCHEMA_VIOLATION
  (`test_m1_validate.py`, `test_m1_spark_open.py`) now expect
  NOT_IN_DICTIONARY for those cases, per U58.
- The three frozen files are unchanged: `odin/instructions/system_prompt.md`
  still hashes to sha256:3a91b23fd4a533c04a8821fa01743c7d6e0062b6956a02eae703864220cf9f8c,
  and the freeze guard passes. `odin/loop/validate.py` was not frozen;
  `odin/loop/prompt.py` is untouched.

## Tests run

`python -m pytest odin/tests/` in the project .venv on 2026-10-28:
181 passed, 1 skipped (the real-key match test this sandbox cannot read; it
runs on the Director's machine with `ODIN_KEY_MATCH_REQUIRED=1`).
New coverage is in `odin/tests/test_m9_dictionary.py` (22 tests).

Red cases, each planted in the real implementation, shown with its test
running and failing for that reason, then restored byte for byte (SHA-256
verified against the pre-plant values):
(a) the no-match fallback returning the INST entry instead of HUGINN — an
INST command was accepted under a HUGINN plan; the tests failed.
(b) the dictionary file's SHA-256 check disabled — one changed byte in a
copy of INST.yaml was accepted; the test failed.
(c) dictionary errors returned as SCHEMA_VIOLATION — the
NOT_IN_DICTIONARY test failed.
(d) two registered dictionaries returning the first match instead of
raising — a plan listing both sent a request; the loop and unit tests failed.

No paid call was made.

## Suggested commit message

M9: dictionary in force from the plan through config/dictionaries.yaml (U58)

Built-with: Muse Code (muse-wonder-1.0)
