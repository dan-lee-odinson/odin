# Deposit MC-M10-01

- Milestone: M10, the two defects PH1-SHAKEDOWN-SPARK-R1 found: read-only
  tool requests built by hand in the loop, and cross-file `$ref`s in the
  schemas the spark adapter sends to Meta.
- Status: deposited as MC-M10-01.zip on the Director's word, 2026-10-28.
- Layout: DEPOSIT.md sits at the top of the deposit zip beside `odin/`. The
  copy beside the zip is named MC-M10-01.DEPOSIT.md so a later deposit
  cannot overwrite it, and is identical to the one inside.
  keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-28 (full suite and red cases shown in session).

## The fixes

1. Tool requests (`odin/loop/loop.py`, `_tool_handler`). Every query string
   is built with `urllib.parse.urlencode`. `points` accepts a
   comma-separated string with or without spaces, or a list of names, and
   reaches the harness joined by commas with no spaces (U19); `window_s`
   passes as the model gives it. The tool definitions sent to the model are
   unchanged. A harness refusal body still goes back as the tool's result;
   any other error in a tool request now does the same — the model gets a
   short text naming the error as that tool's result, the error is written
   to standard error, and the turn goes on instead of ending.
2. Structured output (`odin/adapters/spark.py`, `resolved_schema` in
   `odin/loop/validate.py`). The spark adapter now sends Meta the answer
   or report-body schema with every `$ref` resolved inline, derived from
   the frozen schema files at call time. The files are byte for byte.
   Tests check the derived schema has no `$ref` left and that it accepts
   and rejects the same documents as the frozen one, over the examples in
   `contract/schemas/examples` (answer and report_body), hand-made
   wrong-type documents, and the canonical vectors.
   `spark_open`'s answer tools carry no `$ref` in their parameters (a test
   checks), so they needed no treatment.

## Unverified, for the Director

Nothing was added beyond inlining the `$ref`s: no `strict` flag, and the
answer schema's `oneOf` (over the three answer forms) is sent as the
frozen schema gives it, inlined. Whether Meta's structured output
enforces `oneOf`, or needs a strict flag, is unverified — nothing from
Meta says what it enforced in the shakedown run. The dev run will show it.

## Tests run

`python -m pytest odin/tests/` in the project .venv on 2026-10-28:
204 passed, 1 skipped (the real-key match test this sandbox cannot read; it
runs on the Director's machine with `ODIN_KEY_MATCH_REQUIRED=1`).
New coverage is in `odin/tests/test_m10_tools_schema.py` (22 tests).

Red cases, each planted in the real implementation, shown with its test
running and failing for that reason, then restored byte for byte (SHA-256
verified against the pre-plant values):
(a) the docs query put into the URL raw — a query with a space never
reached the harness; (b) points-string normalization removed —
"A, B" went with its space; (c) points sent as `str(list)` — a list went
as Python's repr; (d) the tool-error handler re-raising — a tool error
ended the turn; (e) the spark adapter sending the schema as loaded — a
`$ref` was left in what Meta got.

## Unchanged

The three frozen files still hash as recorded (system_prompt.md
sha256:3a91b23f…f8c; template.md; prompt.py), the freeze guard passes, the
six schemas the instructions and adapters read (answer, report_body,
report, turn_bundle, observation, common) and `config/models.yaml` are
unchanged, and no contract schema file was touched. No paid call was
made; Claude Code flies the unscored spark run after this deposit is
committed.

## Suggested commit message

M10: encoded tool requests with errors returned to the model; $ref-free schemas for Meta

Built-with: Muse Code (muse-wonder-1.0)
