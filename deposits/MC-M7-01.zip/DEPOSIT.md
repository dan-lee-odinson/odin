# Deposit MC-M7-01

- Milestone: M7, ODIN's instructions (CONTRACT.md §5, §10.4; .agents/AGENTS.md §5, §7),
  built ahead of M5/M6 because phase 1 is a scored run and the instructions freeze first.
- Status: deposited as MC-M7-01.zip on the Director's freeze word, 2026-10-28.
- Layout: this file sits at the top of the deposit zip, beside `odin/`, identical to
  the copy beside the zip. keys/odin.pub is unchanged since MC-M1-01 and is not included.
- Date the Director saw it run: 2026-10-28 (full rendered text shown in session and
  checked on disk by the Director across three review rounds).

## The freeze

- Frozen instructions: odin/instructions/system_prompt.md,
  SHA-256 sha256:3a91b23fd4a533c04a8821fa01743c7d6e0062b6956a02eae703864220cf9f8c,
  line feeds only; the recorded hash is the hash of the file's exact bytes.
- Frozen at 2026-10-28T12:45:56Z (system clock), recorded in
  odin/instructions/system_prompt.sha256.json together with the template hash
  (odin/instructions/template.md, sha256:56f024a5570372d4fd88305da8d6c3e76c918fcf
  26bda9cb8adb25216537459a) and the prompt-template hash (odin/loop/prompt.py,
  sha256:63286e9bfd310af6ee5b7e34df867f78a3d483e7e4c192d375bf5c552fd5a282).
- Guard: a test fails if any of the three files changes, or if rendering the
  template no longer reproduces the frozen bytes.

## What the instructions are

Rendered by odin/instructions/render.py from contract/schemas at build time:
the three answer forms, the escalation kinds and urgencies, the report fields
and report kinds, the bundle fields, the observation fields (including the
refreshed ground_link, with its state enum), and this build's two rungs are
rendered, never typed. A test that adds a field to a copied schema changes
the rendered text. The instructions name no spacecraft command, telemetry
point or procedure (checked against the HUGINN dictionary); they say where
ODIN finds them (the bundle: plan, procedures, hash-attached references
including the dictionary in force and the frozen COSMOS reference). They
cover the classes and the two rungs, envelope raising, leases and uses_left,
the protective commands' position at both rungs, the freshness rule
(NO_FRESH_TELEMETRY), run/plan binding (WRONG_RUN, PLAN_MISMATCH, voiding),
BALDUR-0's feedback (ALLOW; REFUSE naming the first failed check; VOIDED on
recheck before dispatch), the two read-only tools and their limits, contact
and seat with queued escalations, the 60 s turn rhythm, revocation (one
action turn, then HAND_BACK), and the report form. Nothing about any
particular fault, scenario or expected answer.

Director review rounds incorporated: only this build's rungs (rendered);
protective commands open at AI_AUTONOMOUS whatever the plan says and refused
at HUMAN_ONLY; no advice of our own ("prefer to wait" removed, and later an
interpretive ground_link sentence removed); VOIDED as recheck-before-dispatch
with plan boundaries one case among others; history as one row per received
frame with the bundle's 300 s, no downsampling; the Director's words, no
astronaut; a plan's objectives and contact window, not a schedule;
ground_link described as COSMOS's interface for the spacecraft's link, its
state as COSMOS reports it and the packets that interface has received,
naming no interface.

## Two fixes built first (each with a test and a live planted red case)

1. fetch_docs as a script no longer rewrites the recorded hash list: a plain
   run fetches into the cache and checks it against the list (mismatch exits
   non-zero); writing a new list takes --write-hashes and refuses when one
   exists. Planting record-always failed the never-writes test; restored.
2. The no-docs repository test is split: the repository check always runs;
   the cache check skips with a clear message in a fresh clone and runs
   when a cache exists, with a red case catching one changed byte.

## Tests run

`python -m pytest odin/tests/` in the project .venv: 150 passed, 1 skipped
(the real-key match test this sandbox cannot read). Red phases: M7 tests
5 failed against the stub renderer; both fixes' tests failed before their
fixes. Live planted reds shown failing and restored byte for byte: typed
escalation kinds (which first slipped a weaker assertion — the test was
strengthened to pin the rendered kinds line), typed four-rung line, and
CRLF writing in freeze() (the frozen hash is of exact bytes; a CRLF copy
hashes differently).

## Suggested commit message

M7: ODIN's instructions rendered from schemas and frozen at sha256:3a91b23f

Built-with: Muse Code (muse-wonder-1.0)
